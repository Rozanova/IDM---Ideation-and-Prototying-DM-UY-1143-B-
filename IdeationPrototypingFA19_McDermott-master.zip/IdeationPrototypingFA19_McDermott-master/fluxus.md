# Fluxus Instruction Score

Inspired by the Fluxus Performance Workbook.
Create your own Fluxus Performance Score and document it in 2–4 photos. More detail will be given in class. 
