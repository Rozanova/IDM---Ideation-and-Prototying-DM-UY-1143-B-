# Attend a Lecture
Attend a lecture, performance or exhibition, post a 250-500 word write-up to your website giving a quick summary of the event, and more importantly, your reaction to it. 
More suggestions on possible events to visit will be given later in the semester. 
If you have an event in mind, and aren't sure if it will satisfy the course requirements, send the instructor a quick email to verify or ask in person.

