# DM-UY 1143-D Ideation and Prototyping

Ideation and Prototyping (DM-UY 1143), Integrated Digital Media, Tandon School of Engineering, NYU. Fall 2018. Kathleen McDermott, kmcdermott@nyu.edu 

Visit this site regularly for course updates and weekly information.

First day: Click [Invite Link](https://join.slack.com/t/nyuidmideationfa19/shared_invite/enQtNzQxNjg2NDMyODAwLWMwMmE0ZjljMjY5NzI2OWNjNTU5MDAzOThiYjIwOWE2NmZiMGU2ZTBiMzQzMGQxZjJjZjViNTExMWYxZjU3YzE) for Slack 
