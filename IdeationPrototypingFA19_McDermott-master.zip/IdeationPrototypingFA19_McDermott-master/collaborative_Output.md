# I. Classmate Discovery: Interview and Map (in-class lab)

We will make teams in class the week before this lab. During the lab, interview your partner and try to develop and "input map" of their influences and interests. You may also look at their class site. They will do the same for you. After you've both completed your maps, compare them, and devise a plan for a collaborative constant output post. 

# II. Collaborative Constant Output

Put your normal Constant Input on hold this week, and produce a collaborative post together.   
