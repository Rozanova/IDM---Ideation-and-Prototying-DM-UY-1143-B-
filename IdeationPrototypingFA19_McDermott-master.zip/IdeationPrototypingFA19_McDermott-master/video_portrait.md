# Video Self-Portrait 

Create a short (2–5 minute) video self-portrait. The only requirement is that you must not use footage of yourself. For example, you may tell a story (literal or abstract) through objects, you may produce a first-person account and take us through a day in your life, you may employ friends to create a re-enactment...I encourage you to be as creative as possible, and choose a story-telling medium that is meaningful to you.    
