# Laser Cut Tool Box

Design a "tool box" that suits your unique needs as a creative practitioner. This may mean a slim box to hold your USB sticks, or a larger box, with divisions, to hold your suite of drawing tools. It may not take the form of a box at all. But it must be **functional** to suite your needs, and some element of the tool box must be laser cut. 

This assignment is designed to ensure that you have completed your makerspace training, and to help you become acquainted with the laser cutter ealy in the semester. It is also an opportunity to exercise your design ideation skills, and hopefully make something useful!  
